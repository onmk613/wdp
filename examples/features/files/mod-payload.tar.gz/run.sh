#!/bin/sh
echo "payload ready"
