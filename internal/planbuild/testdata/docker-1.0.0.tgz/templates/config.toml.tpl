version = 2
root = "{{ dig "data_dir" (printf "%s/containerd" .data_dir) . }}"
state = "/run/containerd"
