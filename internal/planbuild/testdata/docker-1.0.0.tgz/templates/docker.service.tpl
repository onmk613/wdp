[Unit]
Description=Docker Application Container Engine
Documentation=https://docs.docker.com
After=network-online.target time-set.target
Wants=network-online.target
StartLimitBurst=3
StartLimitIntervalSec=60

[Service]
Type=notify
ExecStart={{ .bin_dir }}/dockerd \
  -H unix:///var/run/docker.sock \
  --containerd=/run/containerd/containerd.sock
ExecReload=/bin/kill -s HUP $MAINPID
TimeoutStartSec=0
Restart=always
RestartSec=2
LimitNOFILE=1048576
LimitNPROC=infinity
LimitCORE=infinity
TasksMax=infinity
Delegate=yes
KillMode=process
OOMScoreAdjust=-500

[Install]
WantedBy=multi-user.target